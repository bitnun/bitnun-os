import express from 'express'
import axios from 'axios'

const router = express.Router()

router.get('/ticker', async (req, res) => {
  const { data } = await axios.get('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT')
  res.send(data)
})

export default router
