import { useState } from 'react'

export function Generators() {
  const [brandName, setBrandName] = useState('')
  const [logo, setLogo] = useState('🦄')

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">🎨 Generators</h2>

      <div className="mb-6">
        <h3 className="font-bold">🖼 Logo Generator</h3>
        <input className="border p-2" placeholder="Brand Name" value={brandName} onChange={e => setBrandName(e.target.value)} />
        <p className="mt-2 text-3xl">{logo} {brandName}</p>
      </div>

      <div className="mb-6">
        <h3 className="font-bold">😂 Meme Coin Name</h3>
        <p>Generated: $WIF, $MOON, $WAGMI, $SLOTH</p>
      </div>

      <div>
        <h3 className="font-bold">📄 Whitepaper Wizard</h3>
        <p>Coming soon: Fill in questions → generates doc</p>
      </div>
    </div>
  )
}
