import { useState } from 'react'

export function Scanner() {
  const [address, setAddress] = useState('')
  const [result, setResult] = useState<any>(null)

  const scan = async () => {
    // Replace with real on-chain scanner API
    setResult({ name: 'MemeToken', symbol: 'MEME', holders: 1234 })
  }

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">🔍 Contract Scanner</h2>
      <input className="border p-2" value={address} onChange={e => setAddress(e.target.value)} placeholder="Enter Token Address" />
      <button className="ml-2 bg-blue-600 text-white px-4 py-2 rounded" onClick={scan}>Scan</button>
      {result && <div className="mt-4">
        <p>Name: {result.name}</p>
        <p>Symbol: {result.symbol}</p>
        <p>Holders: {result.holders}</p>
      </div>}
    </div>
  )
}
