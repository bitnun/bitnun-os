import { useEffect, useState } from 'react'
import axios from 'axios'

export function Dashboard() {
  const [btc, setBtc] = useState('')
  useEffect(() => {
    axios.get('/api/binance/ticker').then(res => setBtc(res.data.price))
  }, [])
  return <h2>BTC/USDT: ${btc}</h2>
}
