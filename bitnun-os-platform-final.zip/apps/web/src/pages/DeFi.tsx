import { useState } from 'react'

export function DeFi() {
  const [apy, setApy] = useState('23.5')
  const [staked, setStaked] = useState('5000')

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">DeFi Dashboard</h2>
      <p>🧾 Current APY: {apy}%</p>
      <p>🪙 Your staked: {staked} BMC</p>
      <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded">Stake More</button>
    </div>
  )
}
