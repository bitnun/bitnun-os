export function TelegramBot() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📡 Telegram Bot</h2>
      <p>Webhook ready Telegram bot to notify user on token launches, trades or meme events.</p>
      <p>Check logs in your bot dashboard or Telegram dev panel.</p>
    </div>
  )
}
