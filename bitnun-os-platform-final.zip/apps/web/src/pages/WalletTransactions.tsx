import { useEffect, useState } from 'react'
import axios from 'axios'

export function WalletTransactions() {
  const [address, setAddress] = useState('')
  const [txs, setTxs] = useState<any[]>([])

  const fetchTxs = async () => {
    const { data } = await axios.get(`https://api.etherscan.io/api?module=account&action=txlist&address=${address}&sort=desc&apikey=YourEtherscanAPIKey`)
    setTxs(data.result || [])
  }

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📜 Wallet Transactions</h2>
      <input className="border p-2" value={address} onChange={e => setAddress(e.target.value)} placeholder="Enter wallet address" />
      <button onClick={fetchTxs} className="ml-2 px-4 py-2 bg-blue-600 text-white rounded">Fetch</button>
      <ul className="mt-4">
        {txs.slice(0, 5).map(tx => <li key={tx.hash}>Hash: {tx.hash.slice(0, 10)}... | Gas: {tx.gasUsed}</li>)}
      </ul>
    </div>
  )
}
