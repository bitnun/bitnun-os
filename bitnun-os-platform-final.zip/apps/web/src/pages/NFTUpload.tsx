import { useState } from 'react'
import { Web3Storage } from 'web3.storage'

export function NFTUpload() {
  const [file, setFile] = useState<File | null>(null)
  const [cid, setCid] = useState('')

  const uploadToIPFS = async () => {
    if (!file) return
    const client = new Web3Storage({ token: import.meta.env.VITE_WEB3STORAGE_KEY })
    const cid = await client.put([file])
    setCid(cid)
  }

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📦 Upload NFT to IPFS</h2>
      <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} />
      <button className="mt-4 bg-purple-700 text-white px-4 py-2 rounded" onClick={uploadToIPFS}>Upload</button>
      {cid && <p className="mt-4 text-green-600">✅ Uploaded: {cid}</p>}
    </div>
  )
}
