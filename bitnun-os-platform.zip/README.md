# Bitnun OS

Bitnun OS is the most complete fullstack platform on the web — combining DeFi, Web3, AI, Generators, Trading, Launchpads, Admin tools, and more.

## Stack
- React + Vite + Tailwind
- Express API
- Drizzle ORM + PostgreSQL
- Stripe, Binance, OpenAI
- Render Ready

## Setup
```bash
cd apps/api && npm install && npm run dev
cd apps/web && npm install && npm run dev
```

## Deploy on Render
Use `render.yaml` and the provided `.env.example` file.
