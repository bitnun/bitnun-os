export function Analytics() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📊 On-Chain Analytics</h2>
      <ul className="list-disc ml-6">
        <li>Total Wallets: 12,321</li>
        <li>Tracked Tokens: 82</li>
        <li>Top Gas Spender: 0x123...FEE</li>
        <li>Most Traded Token: $DEGEN</li>
      </ul>
    </div>
  )
}
