import { useEffect, useState } from 'react'
import { Line } from 'react-chartjs-2'

export function Chart() {
  const [data, setData] = useState([40000, 40500, 41000, 40750, 41500])

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📈 Token Chart</h2>
      <Line
        data={{
          labels: ['1m', '2m', '3m', '4m', '5m'],
          datasets: [{ label: 'BTC/USDT', data, fill: false, borderColor: 'rgb(75, 192, 192)' }]
        }}
      />
    </div>
  )
}
