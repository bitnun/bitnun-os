import { useState } from 'react'

export function NFTMint() {
  const [file, setFile] = useState<File | null>(null)
  const [minted, setMinted] = useState(false)

  const uploadAndMint = async () => {
    if (!file) return alert('No file selected')
    // Simulate upload to IPFS and mint
    setTimeout(() => setMinted(true), 1000)
  }

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">🖼 NFT Mint</h2>
      <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} />
      <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded" onClick={uploadAndMint}>Upload + Mint</button>
      {minted && <p className="text-green-600 mt-4">✅ NFT minted successfully!</p>}
    </div>
  )
}
