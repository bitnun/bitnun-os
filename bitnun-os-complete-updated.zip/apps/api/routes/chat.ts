import express from 'express'
import OpenAI from 'openai'
const router = express.Router()
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! })

router.post('/ask', async (req, res) => {
  const { message } = req.body
  const reply = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: message }],
  })
  res.send({ reply: reply.choices[0].message.content })
})

export default router
