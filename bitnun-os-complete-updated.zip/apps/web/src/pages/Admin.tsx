import { useEffect, useState } from 'react'
import axios from 'axios'

export function Admin() {
  const [users, setUsers] = useState<any[]>([])

  useEffect(() => {
    axios.get('/api/admin/users').then(res => setUsers(res.data))
  }, [])

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">🛠 Admin Panel</h2>
      <ul>
        {users.map(u => (
          <li key={u.id}>{u.username}</li>
        ))}
      </ul>
    </div>
  )
}
